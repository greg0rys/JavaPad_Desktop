package src.ChildClasses;

import src.BaseClasses.Note;
import src.Constants.NoteType;

public class ToDo extends Note {

    public ToDo()
    {
        super("", NoteType.TODO,"");
    }
}
