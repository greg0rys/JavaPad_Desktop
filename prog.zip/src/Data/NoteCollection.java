package src.Data;

public class NoteCollection {

}
