package src.Constants;

public enum NoteType {
    LONG,
    SHORT,
    ARTICLE,
    MEMO,
    TODO,
    REMINDER
}
